package com.gangsan21.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
